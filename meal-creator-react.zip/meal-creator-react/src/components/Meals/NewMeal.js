import "./NewEdit.css"

function NewMeal() {
    return (
        <section class="meals-form-cont">
            <div class="overlay"></div>

            <section class="container meals-menu-cont p-0 overflow-auto">
                {/* <div class="flash-container"> <%- include('../partials/flash') %> </div> */}

                <form class="d-inline-block meal-new-form" action="/meals/new/name/<%=mealName%>/new" method="post">
                    <div class="meal-name-header d-flex justify-content-center align-items-center">Meal Name:
                        {/* <input type="text" name="mealName" class="meal-form-category name-field" placeholder=<%=mealName%> <% if (mealName !== "Untitled") { %> value=<%=mealName%> <% } %>> */}
                        <input type="submit" class="add-name-button" value="V" />
                    </div>
                </form>

                <form class="d-inline-block meal-new-form" action="/meals/new/ingredients/<%=mealName%>/new" method="post">
                    <div class="d-flex justify-content-md-start justify-content-center align-items-center ingredient-field-cont">
                        <input type="text" name="ingredients" class="meal-form-category ingredient-field" placeholder="Enter an Ingredient" />
                    </div>
                    <div class="meal-form-button d-flex justify-content-md-start justify-content-center align-items-center">
                        <input type="submit" class="add-ingredient-button" value="Add Ingredient" />
                    </div>
                </form>

                <div class="row d-flex justify-content-md-start justify-content-center ingredient-row mt-3">
                    {/* <% for (ingredient of item.ingredients) { %> */}
                    <form class="d-block ingredient-form" action="/meals/edit/ingredients/<%=ingredient%>/<%=mealName%>/new?_method=DELETE" method="post">
                        {/* <div class = "tag d-flex align-items-center" id="ingredient-tag"><%=ingredient%><input type="image" class="cancel-tag" src="https://res.cloudinary.com/meal-creator/image/upload/v1662276052/icons/cancel.png"></div> */}
                    </form>
                    {/* <% } %>  */}
                </div>

                <div class="mt-3">
                    {/* <% for (let section of choiceArr) { %> */}
                    <div class="choose-tag d-flex align-items-center justify-content-md-start justify-content-center">
                        {/* <% for (let choice of section) { %>  */}
                        <form class="d-flex tag-btn" action="/meals/new/tags/<%=choice%>/<%=mealName%>/new" method="post">
                            {/* <% if (item.tags.includes(choice)) { %>  */}
                            {/* <button type="submit" class="btn btn-light meal-edit tag-list-check" id="<%=choice.toLowerCase()%>-tag"></button><span class="tag-text"><%=choice%></span> */}
                            {/* <% } else { %>  */}
                            {/* <button type="submit" class="btn btn-light meal-edit tag-list-check filter" id="<%=choice.toLowerCase()%>-tag"></button><span class="tag-text"><%=choice%></span>               */}
                            {/* <% } %>  */}
                        </form>
                        {/* <% } %> */}
                    </div>
                    {/* <% } %> */}
                </div>

                <form class="d-block meal-new-form" action="/meals/new/name-img/<%=mealName%>" method="post" enctype="multipart/form-data">
                    <div class="choose-file-btn d-flex align-items-center justify-content-md-start justify-content-center">
                        <input name="imgSrc" type="file" class="file-form-button form-control" id="customFile" />
                    </div>
                    <div class="d-flex justify-content-center done-row">
                        <span class="form-cancel-btn d-flex justify-content-start align-items-center">
                            <button type="button" class="cancel-button">Cancel</button>
                        </span>
                        <span class="form-submit-btn d-flex justify-content-end align-items-center">
                            <input type="submit" class="done-button" value="Done" />
                        </span>
                    </div>
                </form>

            </section>
        </section>
    );
}

export default NewMeal;