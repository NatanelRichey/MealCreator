import { useState } from "react";
import "./Overlay.css"
import "../Pages/Pantry Pages/PantryList.css"

function ListPage(props) {
    const [enteredItem, setEnteredItem] = useState('');

    const itemChangeHandler = (event) => {
        setEnteredItem(event.target.value);
    }

    const submitHandler = (event) => {
        event.preventDefault();

        const itemData = {
            name: enteredItem
        }

        props.onAddItem(itemData);

        setEnteredItem('');
    };

    return (
        <section class="list-page-cont">
            <div class="overlay"></div>
            <section class="container pantry-menu-cont page p-0 overflow-auto">
                {/* <%- include('./partials/flash') %> */}
                {/* <% for (cat of shoppingCategories) { %> */}
                <section class="<%= cat.toLowerCase() %>-section list-category">
                    {/* <div class="category-row category-col d-flex justify-content-center align-items-center p-0"><%= cat in twoWordCats ? twoWordCats[cat] : cat %><img src="https://res.cloudinary.com/meal-creator/image/upload/v1662276054/icons/<%=cat.toLowerCase()%>.png" class="category-icon"></div> */}
                    <div class="category-row justify-content-start d-flex align-items-center p-0">
                        <form action="/shopping-list/<%=cat%>" method="post" class="validated-form form-container" onSubmit={submitHandler}>
                            {/* <button type="submit" disabled style="display: none" aria-hidden="true"></button> */}
                            <input type="text" name="name" placeholder="Add Item" class="search-category" value={enteredItem} onChange={itemChangeHandler}/>
                            <input type="submit" value="" id="new-item-pantry-btn" class="btn btn-light add-button add-pantry-button d-flex justify-content-center align-items-center p-0" />
                        </form>
                    </div>

                    {/* <% for (let item of items) { %> */}
                    {/* <% if (item.category === cat) { %> */}
                    <div class="row list-item-bar m-0" title="<%=cat.toLowerCase()%>-section pantry-category">
                        <form class="d-flex form-container" action="/shopping-list/move-to-pantry/<%=item.name%>" method="post">
                            <div class="col-sm-1 d-flex justify-content-begin align-items-center p-0 check-col">
                                <input type="image" class="btn btn-light list-check" value="" />
                            </div>
                        </form>
                        <form class="d-flex form-container" action="/shopping-list/<%=item._id%>?_method=PATCH" method="post">
                            {/* <button type="submit" disabled style="display: none" aria-hidden="true"></button> */}
                            <div class="col-sm-11 p-0">
                                <input type="text" name="name" id="saved-item-edit" class="item-edit" value="<%= item.name %>" placeholder="<%= item.name %>" />
                            </div>
                            <div class="col-1 d-flex justify-content-start align-items-center p-0">
                                <input type="submit" id="pantry-enter-btn" class="btn btn-light enter-btn-list" value="" />
                            </div>
                        </form>
                        <form class="form-container" action="/shopping-list/<%=item._id%>?_method=DELETE" method="post">
                            <div class="col-sm-1 d-flex align-items-center p-0">
                                <input type="submit" class="btn btn-light trash-btn" value="" />
                            </div>
                        </form>
                    </div>
                    {/* <% } %> */}
                    {/* <% } %> */}
                </section>
                {/* <% } %> */}
            </section>
        </section>
    );
}

export default ListPage;