import "./Overlay.css"
import "./MealPage.css"
import { useState } from "react";

function MealPage(props) {
    return (
        <section class="meals-page-cont">
            <div class="overlay"></div>
            <section class="container meals-menu-cont p-0 overflow-auto">
                <div class="d-flex justify-content-start align-items-center p-0">
                    <input type="search" placeholder="Enter a Meal" class="meal-search-category" id="meal-search-bar"/>
                        <button class="btn btn-light search-btn"></button>
                </div>
                <div class="category-col d-flex justify-content-begin align-items-center p-0 add-meals-text">
                    <button class="btn btn-light add-meal-button d-flex justify-content-begin align-items-center p-0"><span class="add-meal-txt">Add Meal</span></button>
                    <div class="add-meal-btn"></div>
                </div>
                {/* <div class="flash-container"> <%- include('../partials/flash') %> </div> */}
                {/* <% for (meal of meals) { %> */}
                <div class="row meal-list-item m-0 <%=meal.mealName.toLowerCase()%>">
                    <form class="col-sm-1 meal-form d-flex" action="/meals/edit/all/<%=meal.mealName%>" method="post">
                        <div class="d-flex justify-content-start align-items-center p-0 meal-img-col">
                            <input type="image" class="meal-img" src="<%=meal.imgSrc.toLowerCase()%>" value="" />
                        </div>
                    </form>
                    <form class="meal-form d-flex" action="/meals/<%=meal._id%>?_method=PATCH" method="post">
                        <button type="submit" disabled style="display: none" aria-hidden="true"></button>
                        <div class="p-0 meal-search-col col-sm-11 p-0">
                            {/* <input type="text" name="mealName" class="meal-item-edit" value="<%=meal.mealName %>" placeholder="<%= meal.mealName %>"/> */}
                        </div>
                        <div class="col-1 d-flex justify-content-start align-items-center p-0">
                            <input value="" type="submit" class="btn btn-light enter-btn" />
                        </div>
                    </form>
                    <form class="meal-form d-flex" action="/meals/<%=meal._id%>?_method=DELETE" method="post">
                        <div class="col-1 d-flex align-items-center p-0">
                            <input value="" type="submit" class="btn btn-light trash-btn-meal" />
                        </div>
                    </form>
                </div>
                {/* <% } %> */}
            </section>
        </section>
    );
}

export default MealPage;