import "./ChoiceCard.css"

function SecondPage() {
    return (
        <section>
            <div class="row justify-content-around card-group">
                {/* <% for (choice of choiceArr[1]) { %> */}
                <div class="col-11 col-md-4">
                    <div class="<%=choice.toLowerCase()%> card shadow pt-1">
                        <form action="/app/<%=choice%>" method="post">
                            <button type="submit" class="choice-btn">
                                <img type="submit" class="three-choice-card" src="https://res.cloudinary.com/meal-creator/image/upload/v1662276033/page-images/<%=choice.toLowerCase()%>.jpg" />
                                {/* <div class="card-body"><%=choice%></div> */}
                            </button>
                        </form>
                    </div>
                </div>
                {/* <% } %>  */}
            </div>
        </section>
    );
}

export default SecondPage;