import { useState } from "react";

function PantryItemDelete (props) {

    const [editStatus, setEditStatus] = useState(props.editStatus);
    const [showBtn, setShowBtn] = useState('')

    console.log("new state in Delete")

    if(!editStatus){
        setShowBtn("-show");
        console.log("In Delete")
        console.log(editStatus);
        setEditStatus(!editStatus)
    }

    return (
        <form className="form-container" action={"/pantry/" + props.item._id + "?_method=DELETE"} method="post">
            <div className="col-sm-1 d-flex justify-content-begin align-items-center p-0">
                <input type="submit" className={"btn btn-light trash-btn" + showBtn} value=""/>
            </div>
        </form>
    );
}

export default PantryItemDelete;