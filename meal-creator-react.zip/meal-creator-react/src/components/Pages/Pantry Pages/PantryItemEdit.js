import { useState } from "react";

function PantryItemEdit(props) {

    const [showBtn, setShowBtn] = useState('');

    const selectHandler = () => {
        setShowBtn("-show");
        props.onSelectItem(true);
    }

    if (props.inStock) {
        return (
            <form className="d-flex form-container" action={"/pantry/" + props.item._id + "?_method=PATCH"} method="post">
                <button type="submit" disabled style={{ display: "none" }} aria-hidden="true"></button>
                <div className="col-11 p-0 pantry-input-field">
                    <input type="text" name="name" className="item-edit" value={props.item.name} placeholder={props.item.name} onSelect={selectHandler}/>
                </div>
                <div className="col-1 d-flex justify-content-start align-items-center p-0">
                    <input type="submit" id="pantry-enter-btn" className={"btn btn-light enter-btn" + showBtn} value=""/>
                </div>
            </form>
        );
    }

    return (
        <form className="d-flex form-container" action={"/pantry/" + props.item._id + "?_method=PATCH"} method="post">
            <button type="submit" disabled style={{ display: "none" }} aria-hidden="true"></button>
            <div className="col-sm-10 p-0 pantry-input-field">
                <input type="text" name="name" id="saved-item-edit" className="item-edit" value={props.item.name} placeholder={props.item.name} />
            </div>
            <div className="col-sm-1 d-flex justify-content-end align-items-center p-0">
                <input type="submit" id="pantry-enter-btn" className={"btn btn-light enter-btn-saved" + showBtn} value="" />
            </div>
        </form>
    );
}

export default PantryItemEdit;