import { useState } from "react";
import FlashMsg from "/Users/natan/OneDrive/Desktop/meal-creator-react/src/components/Partials/FlashMsg";
import PantryCategoryContainer from "./PantryCategoryContainer";
import "../Overlay.css"
import "./PantryList.css"

const categories = ["Vegetables", "Fruits", "Grains Pasta", "Dairy", "Meat Poultry", "Fish Eggs", "Fats Oils", "Condiments", "Freezer", "Baking", "Nuts Snacks", "Miscellaneous", "Saved Items"];
const twoWordCats = { "Grains Pasta": "Grains & Pasta", "Fish Eggs": "Fish & Eggs", "Fats Oils": "Fats & Oils", "Meat Poultry": "Meat & Poultry", "Nuts Snacks": "Nuts & Snacks" };
let pantryItems = [{name:"Tomato", category: "Vegetables", inStock: true}]

function PantryPage() {
    const [items, setItems] = useState(pantryItems)
    // const [enteredItems, setEnteredItems] = useState([
    //     {"items":items},
    //     {"Vegetables":''},
    //     {"Fruits":''},
    //     {"Grains Pasta":''},
    //     {"Dairy":''},
    //     {"Meat Poultry":''},
    //     {"Fish Eggs":''},
    //     {"Fats Oils":''},
    //     {"Condiments":''},
    //     {"Freezer":''},
    //     {"Baking":''},
    //     {"Nuts Snacks":''},
    //     {"Miscellaneous":''},
    //     {"Saved Items":''},
    // ]);

    // const [enteredCategory, setEnteredCategory] = useState('');

    const getCheckData = (checkData) => {
        let newItem = items.find(item => item.name === checkData[1])
        newItem["inStock"] = !checkData[0]
        setItems(items.map(item => item.name === checkData[1] ? item = newItem : null))
    }

    // const itemChangeHandler = (event) => {
    //     const cat = event.target.parentElement.parentElement.parentElement.firstElementChild.innerText;
    //     // console.log(cat);
    //     setEnteredCategory(cat)
    //     const index = categories.indexOf(cat) + 1;
    //     // console.log(index);
    //     enteredItems[index][cat] = event.target.value; 
    //     // console.log(enteredItems[index][cat])
    //     setEnteredItems(enteredItems);
    //     // console.log(enteredItems);
    // }

    // const newItem = {
    //     name: enteredItems[categories.indexOf(enteredCategory) + 1][enteredCategory],
    //     category: enteredCategory,
    //     inStock: true
    // }

    // const submitHandler = (event) => {
    //     event.preventDefault();
    //     const index = categories.indexOf(enteredCategory) + 1;
    //     enteredItems[0]["items"].push(newItem);
    //     // console.log(enteredItems[0])
    //     enteredItems[index][enteredCategory] = '';
    //     setEnteredItems(enteredItems);
    //     // console.log(enteredItems)
    // };

    return (
        <section className="pantry-page-cont">
            <div className="overlay"></div>
            <section className="container pantry-menu-cont page p-0 overflow-auto">
                <FlashMsg/>
                {categories.map((cat) => (<PantryCategoryContainer cat={cat} catArray={twoWordCats} items={items} onCheckItem={getCheckData}/>))}
            </section >
        </section >
    );
}


export default PantryPage;