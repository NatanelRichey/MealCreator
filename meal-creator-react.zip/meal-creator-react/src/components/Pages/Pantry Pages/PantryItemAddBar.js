function PantryItemAddBar (props) {
    return (
        <div className="category-row justify-content-start d-flex align-items-center p-0">
            <form action={"/pantry/" + props.cat} method="post" className="form-container">
                <button type="submit" disabled style={{ display: "none" }} aria-hidden="true"></button>
                <input type="text" name="name" placeholder="Add Item" className="search-category" value=''/>
                <button type="submit" id="new-item-pantry-btn" className="btn btn-light add-button add-pantry-button d-flex justify-content-center align-items-center p-0"></button>
            </form>
        </div>
    );
}

export default PantryItemAddBar;