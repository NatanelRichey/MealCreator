function PantryCategoryHeader (props) {
    return (
        <div className="category-col category-row d-flex justify-content-center align-items-center">
            {props.cat in props.catArray ? props.catArray[props.cat] : props.cat}
            <img src={"https://res.cloudinary.com/meal-creator/image/upload/v1662276054/icons/" + props.cat.toLowerCase() + ".png"} className="category-icon" />
        </div>
    );
}

export default PantryCategoryHeader