import PantryItemAddBar from "./PantryItemAddBar";
import PantryCategoryHeader from "./PantryCategoryHeader";
import PantryItem from "./PantryItem";
import { useState } from "react";

function PantryCategoryContainer (props) {

    const getCheckData = (checkData) => {
        props.onCheckItem(checkData);
    }
    
    return (
        <section className={props.cat.toLowerCase() + "-section pantry-category"}>
            <PantryCategoryHeader cat={props.cat} catArray={props.catArray}/>
            <PantryItemAddBar cat={props.cat} items={props.items}/>
            {props.items.map((item) => (
                (item.category === props.cat && props.cat !== "Saved Items" && item.inStock) ? <PantryItem inStock={true} item={item} cat={props.cat} onCheckItem={getCheckData}/>
                : (props.cat === "Saved Items" && !item.inStock) ? <PantryItem inStock={false} item={item} cat={props.cat} onCheckItem={getCheckData}/>
                : null 
            ))}
        </section>
    );
}

export default PantryCategoryContainer