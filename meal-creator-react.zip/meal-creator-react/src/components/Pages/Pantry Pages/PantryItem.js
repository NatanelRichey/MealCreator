import PantryItemDelete from "./PantryItemDelete";
import PantryItemEdit from "./PantryItemEdit";
import PantryStockBtn from "./PantryStockBtn";
import PantryMoveToCart from "./PantryMoveToCart";
import { useState } from "react";

function PantryItem (props) {

    const [editStatus, setEditStatus] = useState(false)

    const getCheckData = (checkData) => {
        props.onCheckItem(checkData);
    }

    const getShowBtnStatus = (status) => {
        if(status) {
            setEditStatus(!editStatus);
            console.log("In Item")
            console.log(editStatus);
        };
    }

    if (props.inStock) {
        return (
            < div className="row list-item-bar m-0" title={props.cat.toLowerCase() + "-section pantry-category"} >
            <PantryStockBtn inStock={true} item={props.item} cat={props.cat} onCheckItem={getCheckData}/>
            <PantryItemEdit inStock={true} item={props.item} onSelectItem={getShowBtnStatus}/>
            <PantryItemDelete item={props.item} editStatus={editStatus}/>
            </div>
        );
    }
    return (
        <div className="row list-item-bar m-0" title="saved items-section pantry-category" >
        <PantryStockBtn inStock={false} item={props.item} onCheckItem={getCheckData}/>    
        <PantryItemEdit inStock={false} item={props.item}/>
        <PantryItemDelete item={props.item}/>
        <PantryMoveToCart item={props.item}/>
    </div>
    );
}

export default PantryItem;