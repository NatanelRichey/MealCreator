import { useState } from "react";

function PantryStockBtn (props) {

    let route = "move-back";
    let btnClassName = "uncheck";

    const [checked, setChecked] = useState(props.inStock)

    const submitHandler = (event) => {
        event.preventDefault();
        setChecked(!checked);
        let itemName = event.target.parentElement.childNodes[1].childNodes[1].firstChild.value
        props.onCheckItem([checked,itemName])
    }

    if (props.inStock) { 
        route = "move";
        btnClassName = "check"
    }

    return (
        <form className="d-flex form-container" action={"/pantry/" + route + "/" + props.item.name} method="post" onSubmit={submitHandler}>
            <div className="col-sm-1 d-flex justify-content-begin align-items-center p-0 check-col">
                <input type="image" className={"btn btn-light list-" + btnClassName} value="" />
            </div>
        </form>
    );

}

export default PantryStockBtn;