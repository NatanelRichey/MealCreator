function MoveToCart (props) {
    return (
        <form className="form-container" action={"/pantry/move-to-cart/" + props.item.name} method="post">
            <div className="col-sm-1 d-flex align-items-center p-0">
                <input type="submit" className="btn btn-light cart-btn" value="" />
            </div>
        </form>
    );
}

export default MoveToCart;