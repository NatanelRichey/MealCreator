import Flash from "../Partials/FlashMsg"
import { useState } from "react";
import "./Users.css";

function Login (props) {
    const [enteredUsername, setEnteredUsername] = useState('');
    const [enteredPassword, setEnteredPassword] = useState('');


    const usernameChangeHandler = (event) => {
        setEnteredUsername(event.target.value);
    }

    const passwordChangeHandler = (event) => {
        setEnteredPassword(event.target.value);
    }

    const submitHandler = (event) => {
        event.preventDefault();


        const loginData = {
            username: enteredUsername,
            password: enteredPassword
        }

        props.onLoginData(loginData);

        setEnteredUsername('');
        setEnteredPassword('');
    };

    return (
        <div className="container d-flex justify-content-center align-items-center mt-2">
          <div className="card login-reg shadow pt-1 px-1">
              <h5 className="card-header">Welcome to Meal Creator! - Login</h5>
              <img src="https://images.unsplash.com/photo-1543353071-873f17a7a088?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
                  alt="" className="card-img-top"/>
              <div className="card-body login-reg justify-content-center">
              <Flash/>
                  <form action="/login" method="POST" className="validated-form d-block" onSubmit={submitHandler} novalidate>
                      <div className="d-flex justify-content-between align-items-center">
                          <div>
                              <label className="form-label user-input-labels" for="username">Username</label>
                              <input className="form-control user-input-fields" type="text" id="username" name="username" value={enteredUsername} onChange={usernameChangeHandler} required autofocus/>
                          </div>
                          <div>
                              <label className="form-label user-input-labels" for="password">Password</label>
                              <input className="form-control user-input-fields" type="password" id="password" name="password" value={enteredPassword} onChange={passwordChangeHandler} required/>
                          </div>
                          <div>
                              <button type="submit" className="btn btn-success btn-block user-btn-login d-flex">Login</button>
                          </div>
                      </div>
                  </form>
                  <div className="d-flex justify-content-center"> 
                      <form action="/register" method="GET" className="validated-form" novalidate>
                          <button type="submit" className="btn btn-success btn-block user-btn-reg d-block">&lsaquo; Not Signed Up? Click Here To Register</button>
                      </form>
                  </div>  
              </div>
          </div>
      </div>
    );
}

export default Login