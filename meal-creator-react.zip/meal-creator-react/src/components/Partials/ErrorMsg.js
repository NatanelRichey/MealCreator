import { Error } from "mongoose";

function ErrorMsg() {
    return (
        <div class="row">
            <div class="col-10 offset-1">
                <div class="alert alert-error-custom" role="alert">
                    <h2 class="alert-heading">Error :</h2>
                    <br />
                    <p>{Error.message}</p>
                </div>
            </div>
        </div>
    );
}

export default ErrorMsg;