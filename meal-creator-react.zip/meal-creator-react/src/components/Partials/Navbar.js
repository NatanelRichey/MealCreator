import "./Navbar.css";

function Navbar() {
    return (
        <nav className="navbar navbar-expand-md navbar-light bg-light" id="navbar">
            <div className="container-fluid">
                <a id="logo-name-button" className="nav-link" href="/app">
                    <img src="https://res.cloudinary.com/meal-creator/image/upload/v1662276053/icons/meal-creator-logo.png" width="50" height="50" className="d-inline-block align-top" alt=""/>
                        <span id="brand">MealCreator</span>
                </a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav nav-fill w-100 align-items-center" id="nav-buttons">
                        <li className="nav-item d-flex justify-content-center">
                            <a className="nav-link hover" id="home-button" href="/app">Home</a>
                        </li>
                        <li className="nav-item d-flex justify-content-center">
                            <a className="nav-link hover pl-0 pr-0" id="pantry-button" href="/pantry">Pantry</a>
                        </li>
                        <li className="nav-item d-flex justify-content-center">
                            <a className="nav-link hover" id="list-button" href="/shopping-list">Shopping List</a>
                        </li>
                        <li className="nav-item d-flex justify-content-center">
                            <a className="nav-link hover" id="meal-button" href="/meals">Meals</a>
                        </li>
                        <li className="nav-item d-flex justify-content-center">
                            <a className="nav-link logout-hover" href="/logout">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;