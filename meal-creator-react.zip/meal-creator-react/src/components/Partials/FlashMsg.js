import "./FlashMsg.css"

function FlashMsg() {
  // if (success && success.length) {
  //   return (
  //     <div class="alert alert-warning alert-dismissible fade show" role="alert" id="flash-success">{success}
  //       <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  //     </div>
  //   );
  // }

  // return (
  //   <div class="alert alert-warning alert-dismissible fade show" role="alert" id="flash-error">{error}
  //     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  //   </div>
  // );
}

export default FlashMsg;