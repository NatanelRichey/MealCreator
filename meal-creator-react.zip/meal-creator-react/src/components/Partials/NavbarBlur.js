import "./Navbar.css";

function NavbarBlur() {
    return (
        <div className="mask">   
            <nav className="navbar navbar-expand-md navbar-light bg-light" id="navbar">
            <div className="container-fluid">
                <img src="https://res.cloudinary.com/meal-creator/image/upload/v1662276053/icons/meal-creator-logo.png" width="50" height="50" class="d-inline-block align-top" alt=""/>
                <button className="" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
                </button>
            </div>
            </nav> 
        </div>
    );
}

export default NavbarBlur;