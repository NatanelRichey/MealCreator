import Login from "./components/Users/Login";
import Register from "./components/Users/Register";
import Navbar from "./components/Partials/Navbar";
import NavbarBlur from "./components/Partials/NavbarBlur";
import FilteredPage from "./components/Pages/FilteredPage";
import FirstPage from "./components/Pages/FirstPage";
import SecondPage from "./components/Pages/SecondPage";
import ThirdPage from "./components/Pages/ThirdPage";
import MealPage from "./components/Pages/MealPage";
import EditMeal from "./components/Meals/EditMeal";
import NewMeal from "./components/Meals/NewMeal";
import ListPage from "./components/Pages/ListPage";
import PantryPage from "./components/Pages/Pantry Pages/PantryPage";

// import { useState } from "react";

// const homeNavBtn = document.querySelector('#home-button')
const pantryNavBtn = document.querySelector('#pantry-button')
const listNavBtn = document.querySelector('#list-buton')
const mealsNavBtn = document.querySelector('#meal-button')
const logoutNavBtn = document.querySelector('.logout-hover')
const homeLogoBtn = document.querySelector('#logo-name-button')

const registerDataHandler = (registerData) => {
  console.log("In App.js");
  console.log(registerData);
}

const loginDataHandler = (registerData) => {
  console.log("In App.js");
  console.log(registerData);
}

const addItemHandler = (itemData) => {
  console.log("In App.js");
  console.log(itemData);
}


function App() {

  // pantryNavBtn.addEventListener('click', function (e) {
    return (
      <div>
        <Navbar />
        <PantryPage/>
      </div>
    );
  // });

  // listNavBtn.addEventListener('click', function (e) {
  //   return (
  //     <div>
  //       <Navbar />
  //       <ListPage onAddItem={addItemHandler} />
  //     </div>
  //   );
  // });

  // mealsNavBtn.addEventListener('click', function (e) {
  //   return (
  //     <div>
  //       <Navbar />
  //       <MealPage />
  //     </div>
  //   );
  // });

  // logoutNavBtn.addEventListener('click', function (e) {
  //   return (
  //     <div>
  //       <NavbarBlur />
  //       <Login onLoginData={loginDataHandler} />
  //     </div>
  //   );
  // });

}


export default App;