import mongoose from 'mongoose';

const Schema = mongoose.Schema;

const PantrySchema = new Schema({
    name: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    owner: {
        type: String,
        required: true
    },
    inStock: {
        type: Boolean,
        default: true
    },
    quantity: {
        type: Number,
        default: 1
    },
    unit: {
        type: String,
        default: ''
    },
    addedDate: {
        type: Date,
        default: Date.now
    }
});

export default mongoose.model('Pantry', PantrySchema);

